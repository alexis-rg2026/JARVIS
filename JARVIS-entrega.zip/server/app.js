import { randomBytes } from 'node:crypto'
import express from 'express'

const SESSION_TTL_MS = 8 * 60 * 60 * 1000
const SESSION_COOKIE = 'jarvis_session'
const ALLOWED_CATEGORIES = new Set(['profile', 'preference', 'note'])

function apiError(status, message) {
  return Object.assign(new Error(message), { status })
}

function readCookie(request) {
  const cookies = request.headers.cookie?.split(';') ?? []
  const entry = cookies.find((cookie) => cookie.trim().startsWith(`${SESSION_COOKIE}=`))
  return entry ? decodeURIComponent(entry.trim().slice(SESSION_COOKIE.length + 1)) : null
}

function validateMemory(body) {
  const category = body?.category
  const label = typeof body?.label === 'string' ? body.label.trim() : ''
  const value = typeof body?.value === 'string' ? body.value.trim() : ''

  if (!ALLOWED_CATEGORIES.has(category)) {
    throw apiError(400, 'Selecciona una categoría válida.')
  }
  if (!label || label.length > 80 || !value || value.length > 1000) {
    throw apiError(400, 'El dato debe tener una etiqueta y un valor válidos.')
  }
  return { category, label, value }
}

function validateMessages(body) {
  if (!Array.isArray(body?.messages) || body.messages.length > 200) {
    throw apiError(400, 'El historial no tiene un formato válido.')
  }
  return body.messages.map((message) => {
    if (
      !message ||
      !['jarvis', 'usuario'].includes(message.tipo) ||
      typeof message.texto !== 'string' ||
      message.texto.length > 2000
    ) {
      throw apiError(400, 'El historial contiene un mensaje no válido.')
    }
    return { tipo: message.tipo, texto: message.texto }
  })
}

export function createApp(storage, options = {}) {
  const app = express()
  const sessions = new Map()
  const loginAttempts = new Map()
  const allowedOrigins = new Set(options.allowedOrigins ?? [
    'http://127.0.0.1:5173',
    'http://localhost:5173',
    'http://127.0.0.1:3001',
    'http://localhost:3001',
  ])

  app.disable('x-powered-by')
  app.use('/api', (request, response, next) => {
    const origin = request.get('origin')
    if (origin && !allowedOrigins.has(origin)) {
      next(apiError(403, 'Origen no autorizado.'))
      return
    }
    next()
  })
  app.use('/api', express.json({ limit: '32kb' }))

  function createSession(response, key) {
    const token = randomBytes(32).toString('hex')
    sessions.set(token, { key, expiresAt: Date.now() + SESSION_TTL_MS })
    response.cookie(SESSION_COOKIE, token, {
      httpOnly: true,
      sameSite: 'strict',
      path: '/api',
      maxAge: SESSION_TTL_MS,
    })
  }

  function requireSession(request, response, next) {
    const token = readCookie(request)
    const session = token && sessions.get(token)
    if (!session || session.expiresAt <= Date.now()) {
      if (token) sessions.delete(token)
      next(apiError(401, 'Inicia sesión para acceder a la memoria de JARVIS.'))
      return
    }
    session.expiresAt = Date.now() + SESSION_TTL_MS
    request.memorySession = session
    request.sessionToken = token
    next()
  }

  app.get('/api/status', (request, response) => {
    const session = sessions.get(readCookie(request))
    response.json({
      configured: storage.isConfigured(),
      authenticated: Boolean(session && session.expiresAt > Date.now()),
    })
  })

  app.post('/api/setup', (request, response, next) => {
    try {
      const password = request.body?.password
      if (storage.isConfigured()) {
        throw apiError(409, 'JARVIS ya está configurado. Inicia sesión.')
      }
      if (typeof password !== 'string' || password.length < 12 || password.length > 256) {
        throw apiError(400, 'La contraseña debe tener entre 12 y 256 caracteres.')
      }
      const key = storage.setupPassword(password)
      createSession(response, key)
      response.status(201).json({ ok: true })
    } catch (error) {
      next(error)
    }
  })

  app.post('/api/login', (request, response, next) => {
    try {
      const ip = request.ip
      const attempt = loginAttempts.get(ip)
      if (attempt && attempt.blockedUntil > Date.now()) {
        throw apiError(429, 'Demasiados intentos. Espera un minuto e inténtalo de nuevo.')
      }

      const password = request.body?.password
      const key = typeof password === 'string' ? storage.authenticate(password) : null
      if (!key) {
        const nextAttempt = attempt && attempt.blockedUntil <= Date.now()
          ? { count: 0, blockedUntil: 0 }
          : attempt ?? { count: 0, blockedUntil: 0 }
        nextAttempt.count += 1
        if (nextAttempt.count >= 5) {
          nextAttempt.blockedUntil = Date.now() + 60_000
          nextAttempt.count = 0
        }
        loginAttempts.set(ip, nextAttempt)
        throw apiError(401, 'Contraseña incorrecta.')
      }

      loginAttempts.delete(ip)
      createSession(response, key)
      response.json({ ok: true })
    } catch (error) {
      next(error)
    }
  })

  app.post('/api/logout', (request, response) => {
    const token = readCookie(request)
    if (token) sessions.delete(token)
    response.clearCookie(SESSION_COOKIE, { httpOnly: true, sameSite: 'strict', path: '/api' })
    response.json({ ok: true })
  })

  app.use('/api', requireSession)

  app.get('/api/memories', (request, response) => {
    response.json(storage.listMemories(request.memorySession.key))
  })

  app.post('/api/memories', (request, response, next) => {
    try {
      const memory = validateMemory(request.body)
      const existing = storage.listMemories(request.memorySession.key).find(
        (item) =>
          item.category === memory.category &&
          item.label.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('es') ===
            memory.label.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('es'),
      )
      if (!existing && !storage.canAddMemory(request.memorySession.key)) {
        throw apiError(409, 'La memoria alcanzó su límite de 500 datos.')
      }
      const saved = storage.saveMemory(request.memorySession.key, memory)
      response.status(existing ? 200 : 201).json(saved)
    } catch (error) {
      next(error)
    }
  })

  app.put('/api/memories/:id', (request, response, next) => {
    try {
      const memory = validateMemory(request.body)
      const updated = storage.updateMemory(request.memorySession.key, request.params.id, memory)
      if (!updated) throw apiError(404, 'No se encontró ese recuerdo.')
      response.json(updated)
    } catch (error) {
      if (error.code === 'ERR_SQLITE_CONSTRAINT_UNIQUE') {
        next(apiError(409, 'Ya existe un dato con esa etiqueta en la categoría seleccionada.'))
        return
      }
      next(error)
    }
  })

  app.delete('/api/memories/:id', (request, response) => {
    const deleted = storage.deleteMemory(request.memorySession.key, request.params.id)
    if (!deleted) throw apiError(404, 'No se encontró ese recuerdo.')
    response.json({ ok: true })
  })

  app.get('/api/events', (request, response) => {
    response.json(storage.listEvents())
  })

  app.get('/api/chat', (request, response) => {
    response.json(storage.loadChat(request.memorySession.key))
  })

  app.put('/api/chat', (request, response, next) => {
    try {
      storage.saveChat(request.memorySession.key, validateMessages(request.body))
      response.json({ ok: true })
    } catch (error) {
      next(error)
    }
  })

  app.delete('/api/data', (request, response) => {
    storage.clearAll()
    response.json({ ok: true })
  })

  app.use('/api', (request, response) => {
    response.status(404).json({ error: 'Ruta de API no encontrada.' })
  })

  app.use((error, request, response, next) => {
    if (response.headersSent) {
      next(error)
      return
    }
    if (error.type === 'entity.parse.failed') {
      response.status(400).json({ error: 'La solicitud contiene JSON inválido.' })
      return
    }
    const status = Number.isInteger(error.status) ? error.status : 500
    if (status === 500) console.error('Error en la API de JARVIS:', error)
    response.status(status).json({
      error: status === 500 ? 'Ocurrió un error interno. Inténtalo de nuevo.' : error.message,
    })
  })

  return app
}
